<?php

class LocationsController extends MvcPublicController {
	
}

?>