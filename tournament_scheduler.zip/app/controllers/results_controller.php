<?php

class ResultsController extends MvcPublicController {
	
}

?>