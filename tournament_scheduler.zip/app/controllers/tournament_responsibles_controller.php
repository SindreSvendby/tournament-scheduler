<?php

class TournamentResponsiblesController extends MvcPublicController {
	
}

?>