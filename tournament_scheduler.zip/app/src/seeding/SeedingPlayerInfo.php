<?php

/**
 * Extends the SeedingPlayer class.
 */
class SeedingPlayerInfo extends SeedingPlayer
{
    /**
     * @var TournamentResult[]
     */
    public $tournamentResults;
}
