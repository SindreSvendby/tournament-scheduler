<?php



class RankingLeagueSeedingList implements SeedingList
{

    public function addTeam(SeedingTeam $team) {

    }

    public function seedingTeams()
    {
        // TODO: Implement seedingTeams() method.
    }

    public function count()
    {
        // TODO: Implement count() method.
    }
}
