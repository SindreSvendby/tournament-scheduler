<?php

interface SeedingList
{
    public function seedingTeams();
    public function count();

}
