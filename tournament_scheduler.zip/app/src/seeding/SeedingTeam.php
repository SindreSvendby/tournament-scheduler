<?php

interface SeedingTeam
{
    public function rankingPoints();

    public function seedingPlace();

    public function tournamentsResults();

}
