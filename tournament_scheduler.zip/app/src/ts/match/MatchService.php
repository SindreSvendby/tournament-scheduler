<?php


namespace ts\match;


interface MatchService {

    public function matches($byTournamentId);

}