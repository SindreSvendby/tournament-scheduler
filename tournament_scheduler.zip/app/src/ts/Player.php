<?php
namespace ts;

interface Player
{
    /**
     * @return rankingSerieEntry[]
     */
    public function rankingSerieEnteries();
}
