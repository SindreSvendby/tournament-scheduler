<?php
namespace ts;


interface RankingLeague
{
    public function name();
}
