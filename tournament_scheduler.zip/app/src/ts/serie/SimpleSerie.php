<?php


namespace ts\serie;


interface SimpleSerie {
    public function name();
    public function id();
}