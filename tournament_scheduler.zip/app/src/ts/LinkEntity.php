<?php


namespace ts;


interface LinkEntity {
    public function name();
    public function id();
}