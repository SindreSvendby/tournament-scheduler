<?php


namespace ts\rankinglist\serie;

use ts\LinkEntity;

interface SimpleSerie extends LinkEntity {

}