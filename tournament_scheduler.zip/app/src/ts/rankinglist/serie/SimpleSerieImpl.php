<?php


namespace ts\rankinglist\serie;

use ts\LinkEntityImpl;

class SimpleSerieImpl extends LinkEntityImpl implements SimpleSerie {

}