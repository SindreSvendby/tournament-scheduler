<?php
namespace ts\rankinglist\rankingLeague;


interface RankingLeague
{
    public function name();
    public function id();
}
