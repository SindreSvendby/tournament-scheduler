<?php


namespace ts\rankinglist\rankingLeague;

use ts\LinkEntity;

interface SimpleRankingLeague extends LinkEntity {

}