<?php


namespace ts\ranking;


interface RankingListService {


    public function serie($serie_id);
}