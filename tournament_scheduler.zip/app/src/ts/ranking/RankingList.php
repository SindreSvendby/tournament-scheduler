<?php


namespace ts\ranking;


interface RankingList {
    //public function
}