<?php

namespace ts\volleyball\match\set;

interface Set {
    public function pointsTeamOne();
    public function pointsTeamTwo();
}