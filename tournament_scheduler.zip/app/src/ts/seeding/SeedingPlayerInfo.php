<?php
namespace ts\seeding;

/**
 * Extends the RankingPlayer class.
 */
class SeedingPlayerInfo extends SeedingPlayer
{
    /**
     * @var TournamentResult[]
     */
    public $tournamentResults;
}
