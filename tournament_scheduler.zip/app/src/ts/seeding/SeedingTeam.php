<?php
namespace ts\seeding;

interface SeedingTeam
{
    public function rankingPoints();
    public function teamId();

}
