<?php

interface TournamentSerie
{

    public function rankingleague();
}
