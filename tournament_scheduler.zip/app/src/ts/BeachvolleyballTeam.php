<?php
namespace ts;

class BeachvolleyballTeam implements Team
{

    /**
     * @return Player[]
     */
    public function players()
    {
        // TODO: Implement players() method.
    }


    /**
     * @return RankingSerie[]
     */
    public function rankingSeries()
    {
        // TODO: Implement rankingSeries() method.
    }
}
