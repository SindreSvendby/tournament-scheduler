<?php
namespace ts;


interface RankingLeague
{
    public function name();
    public function id();
}
