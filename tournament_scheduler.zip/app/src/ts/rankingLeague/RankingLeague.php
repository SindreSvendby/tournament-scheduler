<?php
namespace ts\rankingLeague;


interface RankingLeague
{
    public function name();
    public function id();
}
