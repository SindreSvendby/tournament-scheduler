<?php

namespace ts\tournament;

interface TournamentSerie
{

    public function rankingleague();
}
