<?php


namespace ts\tournament;


interface TournamentService {

    public function tournament($id);

}