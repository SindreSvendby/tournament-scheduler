<?php


namespace ts\tournament;

use ts\LinkEntityImpl;
use ts\rankingLeague\SimpleRankingLeague;

class SimpleRankingLeagueImpl extends LinkEntityImpl implements SimpleRankingLeague{

}