<?php

class TournamentResult
{
    public $place;
    public $points;
    public $tournamentName;
    public $teamName;
}
