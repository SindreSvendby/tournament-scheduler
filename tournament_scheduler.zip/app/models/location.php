<?php

class Location extends MvcModel {

	var $display_field = 'name';
	
}

?>