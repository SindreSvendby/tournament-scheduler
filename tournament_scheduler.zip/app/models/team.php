<?php

class Team extends MvcModel {

	var $display_field = 'name';
	
}

?>