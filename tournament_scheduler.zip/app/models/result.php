<?php

class Result extends MvcModel {

	var $display_field = 'name';
    var $belongs_to = array('Tournament');
}

?>