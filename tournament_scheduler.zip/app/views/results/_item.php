<div>
	<?php echo $this->html->result_link($tournament); ?></div>