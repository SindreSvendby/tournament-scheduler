<h2><?php echo $tournament->__name; ?></h2>

<p>
	<?php echo $this->html->link('&#8592; All Results', array('controller' => 'results')); ?>
</p>