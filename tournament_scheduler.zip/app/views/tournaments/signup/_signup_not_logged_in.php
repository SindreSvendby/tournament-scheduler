<p class="login">
    <strong>
        <a href='<?php echo wp_login_url($_SERVER["REQUEST_URI"]) ?>'>Logg inn</a> for og melde deg på turneringen.
    </strong>
</p>
<p>Alle medlemmer av OSVB har en konto, vet du ikke ditt brukernavn og passord, prøv og trykk på logg inn også velg
    'Lost your password?', og skriv inn din mailaddresse.
</p>
<p>Er du ikke medlemm av OSVB, trykk logg inn også login inn via facebook, du blir medlemm av OSVB under
    registeringsprossesen :)
</p>