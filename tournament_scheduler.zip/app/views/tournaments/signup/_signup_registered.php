<p>
    Du er allerede meldt på! For å melde deg av kontakt turneringsansvarlig.
</p>
