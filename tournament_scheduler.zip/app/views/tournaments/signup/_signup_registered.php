<p>
    Du er allerede meldt på, for å melde deg av, kontakt turneringsansvarlig.
</p>
