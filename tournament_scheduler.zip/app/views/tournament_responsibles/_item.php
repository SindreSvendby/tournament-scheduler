<div>
	<?php echo $this->html->tournament_responsible_link($object); ?></div>