<h2><?php echo $tournament->__name; ?></h2>
