<div>
    <?php echo $this->html->rankingleague_link($object); ?>
</div>