<h2>Add Rankingleague</h2>

<?php echo $this->form->create($model->name); ?>
<?php echo $this->form->input('name'); ?>
<?php echo $this->form->input('details'); ?>
<?php echo $this->form->end('Add'); ?>