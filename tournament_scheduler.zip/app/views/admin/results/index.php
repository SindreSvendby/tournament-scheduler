<?php
echo '<a href="'. get_admin_url() .'admin.php?page=mvc_tournaments-results">Register resultater </a>';