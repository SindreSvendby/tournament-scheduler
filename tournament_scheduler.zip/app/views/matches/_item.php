<div>
	<?php echo $this->html->match_link($tournament); ?></div>