<div>
	<?php echo $this->html->location_link($object); ?></div>